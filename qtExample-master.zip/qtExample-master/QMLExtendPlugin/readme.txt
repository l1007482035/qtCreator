生成的dll要拷贝到qt的qml目录下，新建一个这样的层级\com\ink\qmlcomponents

最终目录结构如下

C:\Qt\Qt5.6.1\5.6\msvc2015\qml\com\ink\qmlcomponents
目录下文件为QMLExtendPlugin.dll QMLExtendPlugind.dll qmldir
